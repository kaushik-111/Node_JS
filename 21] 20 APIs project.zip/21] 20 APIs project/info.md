Admin-----------------


1. Admin Registration (username, email, phone, password, role)
2. Admin Login (username or email & password)
3. Profile (show own details) (Admin Token)
4. Change password (Admin Token)
5. Forgot Password (no Token)
6. Add manager detail (Registration - username, email, phone, password, adminId)
(send email and passed details like password, Portal Link) (Admin Token)
11. All managers data show (Admin Token)
12. Manager Delete (Active / Deactive)
19. View All Employee (Admin Token)
20. Employee Delete (Active/ Deactive)



Manager--------------------


7. Manager Login 
8. Profile (show manager details)(Manager Token)
9. Change Password (Manager Token)
10. Forgot Password (No Token)
13. Add Employee by Managers (Registration - Username, email, Phone, password, ManagerId)
(Send email to employee mail for password, portal link) (manager Token)
18. View All Employees (Manager Token)


Employee:---------------------


14. Employee Login
15. Profile (Show Employee details) (Employee Token)
16. Change Password (Employee Token)
17. Forgot Password (No Token)